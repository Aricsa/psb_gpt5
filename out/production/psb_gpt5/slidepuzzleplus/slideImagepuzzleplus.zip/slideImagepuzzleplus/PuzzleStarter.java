package slidepuzzleplus;
public class PuzzleStarter {

	public static void main(String[] args) {
		new PuzzleFrame(new SlidePuzzleBoard());
	}
}
