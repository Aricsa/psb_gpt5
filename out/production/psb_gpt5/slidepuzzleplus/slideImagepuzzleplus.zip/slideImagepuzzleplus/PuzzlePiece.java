package slidepuzzleplus;

import javax.swing.*;
import java.awt.*;

public class PuzzlePiece extends JLabel {
	private int faceValue;
	private Image image;
	public PuzzlePiece(int value) {
		faceValue = value;
	}
	public int getFaceValue() {
		return faceValue;
	}
	public Image getImage() {
		return image;
	}
	public void setImage(Image image) {
		this.image = image;
	}
}